# proyecto_poo

Desarrollo de sistema con paradigma POO

Librerias utilizadas:

<ul>
<li>mysql-connector-python 9.4.0</br>pip install mysql-connector-python</li>
</br>
<li>prettytable 3.16.0</br>pip install prettytable</li>
</ul>

Addons utilizados en VSCode:

<ul>
<li>SonarQube for IDE</li>
</br>
<li>Prettier - Code formatter</li>
</ul>
