def menu_principal():
    print('Sistema de Gestión de Usuarios')
    print('==============================')
    print('[1] Opción 1')
    print('[2] Opción 2')
    print('[3] Opción 3')
    print('[0] Salir')
