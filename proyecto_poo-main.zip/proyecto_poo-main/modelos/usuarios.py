class Usuario(object):
    """docstring for Usuario."""

    def __init__(self, arg):
        super(Usuario, self).__init__()
