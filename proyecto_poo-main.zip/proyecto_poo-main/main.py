from ui.menu_principal import menu_principal

menu_principal()
